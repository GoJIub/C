// #include "main.c" // Внутри main.c происходит вызов functions.h, что ведёт к "бесконечному" вызову друг друга

int div(int a ,int b);

int mod(int a ,int b);

int max(int a, int b);

int min(int a, int b);

int in_triangle(int a, int b);