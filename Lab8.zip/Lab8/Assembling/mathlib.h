int div(int a ,int b);

int mod(int a ,int b);

int max(int a, int b);

int min(int a, int b);

int in_triangle(int a, int b);