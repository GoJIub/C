#include <stdio.h>
#include "mathlib.h"

/* int F(int a) {
    if (mod(a, 2) == 0)
        return "чётное";
    else
        return "нечётное";
}
*/


int main() {

    // printf("%c\n", F(6));

    int d = div(17, 5);
    printf("%d\n", d);

    int md = mod(17, 5);
    printf("%d\n", md);

    int mx = max(17, 5);
    printf("%d\n", mx);

    int mn = min(17, 5);
    printf("%d\n", mn);
    // printf("%d\n" mn); // Забыл поставить запятую после кавычек -> получил синтаксическую ошибку
    
}