a, b = map(int, input().split())
print(max(a, b))