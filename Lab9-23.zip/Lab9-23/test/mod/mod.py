a, b = map(int, input().split())
if b == 0:
    print("Division by zero")
else:
    print(a % b)