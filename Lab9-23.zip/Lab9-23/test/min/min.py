a, b = map(int, input().split())
print(min(a, b))